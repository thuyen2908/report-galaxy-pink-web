(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[6687],{45370:function(e,t,i){(window.__NEXT_P=window.__NEXT_P||[]).push(["/management/service-details",function(){return i(9450)}])},4762:function(e,t,i){"use strict";var a=i(85893),r=i(11163),l=i(67294),n=i(90475),s=i(93346),d=i(58656);t.Z=e=>t=>{let i=(0,r.useRouter)(),{checkRole:c}=e,o=d.ZP.get(n.P.role);if((0,l.useEffect)(()=>{if((0,s.Oy)())return;let t=d.ZP.get(n.P.role),a=t?.find(t=>e[t]);(c&&!(0,s.K0)(t)||c&&!a)&&i.push("/")},[i,c]),!c||(0,s.Oy)()){let i=e[Object.keys(e)[0]];return l.isValidElement(i)?l.cloneElement(i,{...t}):(0,a.jsx)(i,{...t})}if((0,s.K0)(o)){let i=o.find(t=>e[t]);if((0,s.K0)(i)){let r=e[i];return l.isValidElement(r)?l.cloneElement(r,{...t}):(0,a.jsx)(r,{...t})}}return null}},32726:function(e,t,i){"use strict";var a=i(85893),r=i(67294),l=i(54446),n=i(83490);let s=(0,r.forwardRef)(({dataRow:e,loading:t,onRowClick:i,onRowDoubleClick:s,columns:d,title:c,fullHeight:o=!0,sx:u={},countRow:g=!0,rowId:h="id",gridProps:m,privileges:p,showActionColumn:x=!1,confirmText:f,divSubHeader:b=!1,customFilter:v,quickFilterWidth:y},S)=>{let[E,k]=(0,r.useState)({pageSize:10,page:0}),P=(e,t)=>t.split(".").reduce((e,t)=>{if(e&&t in e)return e[t]},e),w={loading:t,rows:e??[],columns:[...g?[{field:"lineNo",headerName:"",width:20,cellClassName:"super-app-theme--cell",editable:!1,filterable:!1,groupable:!1,aggregable:!1,disableColumnMenu:!0,fontWeight:600,color:"red",valueGetter:(e,t,i,a)=>a.current.getAllRowIds().indexOf(P(t,h))+1,valueFormatter:e=>0!==e?e:""}]:[],...d],showActionColumn:x,gridProps:{autoHeight:!1,className:o?"primary-grid content-grid-custom":"",disableMultipleRowSelection:!0,paginationModel:E,onPaginationModelChange:k,getRowId:e=>P(e,h),initialState:{columnVisibilityModel:{id:!1}},...m}};return(0,a.jsx)(r.Fragment,{children:(0,a.jsx)(n.Z,{sx:{height:"100%",width:"100%","& .container-secondary-grid":{height:"100%"},"& .super-app-theme--cell":{color:"var(--pink-text-light)",fontWeight:"500"}," .MuiDataGrid-aggregationColumnHeaderLabel":{display:"none"},".content-grid-custom":{...u}},children:(0,a.jsx)(l.Z,{ref:S,pageSize:50,...w,title:c,divSubHeader:b,loading:t,customFilter:v,spacingProps:!1,privileges:p,onRowClick:e=>{"function"==typeof i&&i(e)},onRowDoubleClick:s,confirmText:f,iconBtn:!0,quickFilterWidth:y})})})});t.Z=s},20142:function(e,t,i){"use strict";var a=i(85893),r=i(32726),l=i(63792),n=i(93346);i(67294);var s=i(27684);let d=[{display:"flex",alignItem:"center",field:"avatar",headerName:"",minWidth:80,groupable:!1,aggregable:!1,sortable:!1,width:80,valueGetter:(e,t)=>`${t?.nickName}`,renderCell:e=>{let{firstName:t,lastName:i,backColor:a,foreColor:r,avatar:l}=e.row;return(0,n.Ew)(l)?(0,n.gk)(t,i,a,r):(0,n.Ik)(l)}},{field:"nickName",headerName:"Name",minWidth:115,width:115,flex:1}];t.Z=({onSelect:e})=>{let{technicians:t}=(0,l.Z)();return(0,a.jsx)(a.Fragment,{children:(0,a.jsx)(r.Z,{gridProps:{...s.tyM},columns:d,countRow:!1,dataRow:t,onRowClick:e})})}},9450:function(e,t,i){"use strict";i.r(t),i.d(t,{default:function(){return $}});var a=i(85893),r=i(67294),l=i(41248),n=i(5152),s=i.n(n),d=i(90475),c=i(8188),o=i(28886),u=i(93346),g=i(58656),h=i(27603),m=i(4762),p=i(70405),x=i(58531),f=i(68573),b=i(27684),v=i(18704),y=i(32726),S=i(22507),E=({data:e,allTechnician:t=!1,handleOnRowClick:i})=>{let{loading:r}=(0,l.v9)(e=>e[o._.REDUX]),{loading:n}=(0,l.v9)(e=>e[v._.REDUX]),{companyProfileResult:s}=(0,l.v9)(e=>e[c._.REDUX]),d=[{field:"nickName",headerName:"Technician",minWidth:120,groupable:!1,aggregable:!1,hideable:!0},{field:"ticketNumber",headerName:"Ticket#",minWidth:80,groupable:!1,aggregable:!1},{field:"itemName",headerName:"Service",minWidth:300,flex:1,groupable:!1,aggregable:!1,valueFormatter:(e,t)=>`${t.menuItemType===b.UIn.ServicePackageItem||t.menuItemType===b.UIn.PrePaidPackageItem?"==":""}${e??""}`},{field:"qty",headerName:"Qty",width:70,groupable:!1,type:b.ga8.Number},{field:"originalPrice",headerName:"Price",minWidth:100,width:120,align:"right",groupable:!1,type:b.ga8.Number,headerAlign:"right",valueFormatter:e=>(0,u.xG)(e)},{field:"nonCashTip",headerName:"NC Tips",minWidth:100,groupable:!1,type:b.ga8.Number,align:"right",headerAlign:"right",valueFormatter:e=>(0,u.xG)(e)},{field:"originalDiscount",headerName:"Discount Total",minWidth:160,align:"right",groupable:!1,type:b.ga8.Number,headerAlign:"right",valueFormatter:e=>(0,u.xG)(e)},{field:"serviceChargeTotal",headerName:"Item Supply Fee",minWidth:180,groupable:!1,type:b.ga8.Number,align:"right",headerAlign:"right",valueFormatter:e=>(0,u.xG)(e)},{field:"supplyCharge",headerName:"Ticket Supply Fee",minWidth:180,groupable:!1,type:b.ga8.Number,align:"right",headerAlign:"right",valueFormatter:e=>(0,u.xG)(e)}];return(0,a.jsx)(y.Z,{fullHeight:!0,columns:d,gridProps:{...b.tyM,disableAggregation:!1,initialState:{aggregation:{model:{serviceChargeTotal:"sum",qty:"sum",originalPrice:"sum",nonCashTip:"sum",originalDiscount:"sum",supplyCharge:"sum"}}}},customFilter:t?null:[(0,a.jsx)(S.Z,{type:"horizontal",firstDayOfWeek:s?.weekStartsOn},"date-range")],dataRow:e??[],loading:r||n,onRowClick:i})},k=i(60762),P=({id:e})=>{let{dataBillServiceDetails:t}=(0,l.v9)(e=>e[v._.REDUX]),{companyProfileResult:i}=(0,l.v9)(e=>e[c._.REDUX]),[n,s]=(0,r.useState)("");return(0,r.useEffect)(()=>{if((0,u.K0)(t)){if(!(0,u.K0)(t?.dataSource)){s("");return}let e=g.ZP.get(d.P.QrCode),a=t?.dataSource;(0,u.Ew)(i?.receiptMessage?.qrCodeCustomerReceipt)||(a=t?.dataSource?.replace("</body>",`<div class='qr'>
						<img src=${e} />
						</div></div></body>`)),s(a)}},[i?.receiptMessage?.qrCodeCustomerReceipt,t]),(0,a.jsx)(r.Fragment,{children:(0,a.jsx)(k.Z,{className:"render-bill",dangerouslySetInnerHTML:{__html:(0,u.K0)(t)?n:""}})})},w=i(9677),I=i(71820),j=i(68780),D=i(20142),T=i(69364),C=i(79010),N=i(85017),R=i(91309),_=i(30381),Z=i.n(_);let W=(0,m.Z)({VIEW_ALL_SERVICE_DETAILS:(0,a.jsx)(T.Fo,{children:(0,a.jsx)(()=>{let e=(0,l.I0)(),t=(0,r.useRef)(""),{getDataResult:i}=(0,l.v9)(e=>e[o._.REDUX]),{companyProfileResult:n}=(0,l.v9)(e=>e[c._.REDUX]),{value:s}=(0,T.zT)(),[h,m]=(0,r.useState)([]),[v,y]=(0,r.useState)(null),[k,N]=(0,r.useState)([]);return(0,r.useEffect)(()=>{let t={dateStart:s?.[0].format(C.qx),dateEnd:s?.[1].format(C.qx)};e(w.f.getPaidServicesByDateRangeAsync(t))},[s]),(0,r.useEffect)(()=>{if((0,u.K0)(i)&&i.result){m(i.dataSource);let e=i.dataSource;(0,u.K0)(v)&&(e=e.filter(e=>e.employeeId===v?.id)),N(e)}},[i]),(0,r.useEffect)(()=>()=>{e(w.f.clearDataEmployeeTicket()),(0,u.FC)(b.uH8.VIEW_ALL_SERVICE_DETAILS),g.ZP.remove(d.P.userSerivceDetails),e(I.Xz.clearDataEmployeeTicket())},[]),(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)(p.ql,{title:"Service Details"}),(0,a.jsxs)(f.ZP,{container:!0,height:"100%",flexWrap:"nowrap",children:[(0,a.jsx)(f.ZP,{item:!0,xs:2,lg:2,height:"100%",position:"relative",children:(0,a.jsxs)(j.Wc,{heightclassic:"278px",heightlinear:"155px",sx:{display:"flex",flexDirection:"column",gap:2},children:[(0,a.jsx)(S.Z,{firstDayOfWeek:n?.weekStartsOn}),(0,a.jsx)(D.Z,{onSelect:i=>{let a=i.row,r=h?.filter(e=>e.employeeId===a?.id);y(a),N(r),e(w.f.changeEmployeeServiceDetails(a.id)),t.current="",g.ZP.set(d.P.userSerivceDetails,{id:a?.id??"",name:a?.nickName??""}),e(I.Xz.clearBillCloseTicket("dataBillServiceDetails"))}})]})}),(0,a.jsx)(f.ZP,{pl:2,item:!0,xs:7.5,lg:7.5,children:(0,a.jsx)(j.Wc,{heightlinear:"155px",children:(0,a.jsx)(x.x4,{children:(0,a.jsx)(E,{data:k,allTechnician:!0,handleOnRowClick:i=>{if(t.current!==i?.id){t.current=i?.id??"";let a={ticketId:i?.row.ticketId??"",updatedAt:i?.row?.updatedAt??null,customerId:i?.row?.customerId??""};e(I.Xz.renderBillCloseTicket({keyData:"dataBillServiceDetails",data:a}))}}})})})}),(0,a.jsx)(f.ZP,{pl:2,item:!0,xs:2.5,lg:2.5,children:(0,a.jsx)(j.Wc,{children:(0,a.jsx)(x.x4,{backgroundTab:!1,isScroll:!0,sx:{overflow:"hidden auto","&::-webkit-scrollbar":{display:"none"}},children:(0,a.jsx)(P,{id:t.current})})})})]})]})},{})}),VIEW_ONLY_SERVICE_DETAILS:(0,a.jsx)(T.Fo,{children:(0,a.jsx)(({isOpen:e,handlePrintTechnician:t})=>{let i=(0,r.useRef)(""),n=(0,l.I0)(),{value:s}=(0,T.zT)(),{getDataResult:c}=(0,l.v9)(e=>e[o._.REDUX]),h=g.ZP.get(d.P.userSerivceDetails),[m,b]=(0,r.useState)([]);return(0,r.useEffect)(()=>{i.current=""},[m]),(0,r.useEffect)(()=>{let e={employeeId:h?.id??"",dateStart:s?.[0].format(C.qx),dateEnd:s?.[1].format(C.qx)};n(w.f.getPaidServiceAsync(e))},[s]),(0,r.useEffect)(()=>{(0,u.K0)(c)&&c.result&&b(c.dataSource)},[c]),(0,r.useEffect)(()=>()=>{(0,u.FC)(N.uH.VIEW_ONLY_SERVICE_DETAILS),n(w.f.clearDataEmployeeTicket()),g.ZP.remove(d.P.userSerivceDetails),n(I.Xz.clearDataEmployeeTicket())},[]),(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)(p.ql,{title:"Service Details"}),(0,a.jsxs)(f.ZP,{container:!0,height:"100%",flexWrap:"nowrap",children:[(0,a.jsx)(f.ZP,{item:!0,xs:9.5,lg:9.5,children:(0,a.jsx)(j.Wc,{heightclassic:"192px",heightlinear:"155px",children:(0,a.jsx)(x.x4,{children:(0,a.jsx)(E,{data:m,allTechnician:!1,handleOnRowClick:e=>{if(i.current!==e?.id){i.current=e?.id??"";let t={ticketId:e?.row.ticketId??"",updatedAt:e?.row?.updatedAt??null,customerId:e?.row?.customerId??""};n(I.Xz.renderBillCloseTicket({keyData:"dataBillServiceDetails",data:t}))}}})})})}),(0,a.jsx)(f.ZP,{pl:2,item:!0,xs:2.5,lg:2.5,children:(0,a.jsx)(j.Wc,{children:(0,a.jsx)(x.x4,{isScroll:!0,sx:{overflow:"hidden auto","&::-webkit-scrollbar":{display:"none"}},children:(0,a.jsx)(P,{id:i.current})})})})]})]})},{})}),checkRole:!0}),F=(e,t,i)=>{let a="",r=0,l=0,n=0;return(e||[]).forEach((e,t,i)=>{l+=e.nonCashTip,n+=e.originalPrice,r+=e.qty,a+=`<tr class="${0===t?"bold-start":t===i.length-1?"bold-end":""}">
			<td class="name">${e.menuItemType===b.UIn.ServicePackageItem||e.menuItemType===b.UIn.PrePaidPackageItem?"==":""}${e.itemName}</td>
			<td class="right-align right-qty">${e.qty}</td>
			<td class="right-align">${(0,u.xG)(e.nonCashTip)}</td>
			<td class="right-align">${(0,u.xG)(e.originalPrice)}</td>
		</tr>`}),`<html>
					<style>
						 .class-address {
							text-align: center;
							margin-top: 0px;
							margin-bottom: 0px;
							line-height: 1.2;
						}

						.table-business {
							width: 100%;
							border-collapse: collapse;
							table-layout: fixed; 
						}

						.dashed-service {
							border-top: 1px dashed black;
							border-bottom: 1px dashed black;
							margin: 10px 0;
						}

						.name {
							text-align: left;
							width: 40%;
						}

						.right-align {
							text-align: right;
							vertical-align: top;
							width: 25%; 
						}

						.center-align {
							text-align: center;
						}

						.border-top {
							border-top: 1px dashed black;
						}

						.border-end {
							border-top: 2px dashed black;
							padding-top: 5px;
						}

						.bold-end>td {
							padding-bottom: 5px
						}

						.bold-first>td {
							padding-bottom: 8px
						}

						.bold-start>td {
							padding-top: 8px
						}

						.container-print {
							font-size: 20px;
							font-family: Verdana;
						}

						.container-print {
							font-size: 25px;
						}

						.table-business {
							font-size: 25px;
						}
						.right-qty{
							width:10%
						}
					</style>
					<body>
						<div class='container-print'>
						<p class='class-address'>${t?.businessName??""}</p>
						<p class='class-address'>${t?.address?.address??""}<br>${t?.address?.city}, ${t?.address?.state} ${t?.address?.zip}<br>${(0,R.un)(t?.phone??"")}</p>
						<table class="table-business">
							<tr>
								<td class="name">Business Date</td>
								<td class="right-align" colspan="3">${Z()(new Date).format(C.GG)}</td>
							</tr>
							<tr>
								<td class="name">Technician Name</td>
								<td class="right-align" colspan="3">${i}</td>
							</tr>
						</table>
						<table class="table-business">
							<tr class="bold-first">
								<td class="name">Service/Prod</td>
								<td class="right-align right-qty">Qty</td>
								<td class="right-align">Tip</td>
								<td class="right-align">Total</td>
							</tr>
							<tr class="border-end">

							</tr>
							${a}
							<tr class="border-end">
							</tr>
							<tr class="bold-start">
								<td class="name">TOTAL</td>
								<td class="right-align right-qty">${r}</td>
								<td class="right-align">${(0,u.xG)(l)}</td>
								<td class="right-align">${(0,u.xG)(n)}</td>
							</tr>
						</table>
						</div>
					</body>
				</html>`},A=s()(()=>Promise.all([i.e(4380),i.e(4285),i.e(1873),i.e(4644),i.e(8315),i.e(3487),i.e(6266),i.e(1290),i.e(4679),i.e(4022),i.e(5063),i.e(8189),i.e(7497),i.e(7434),i.e(6107),i.e(6966),i.e(7520),i.e(5746),i.e(5021),i.e(1069),i.e(3676)]).then(i.bind(i,83913)),{loadableGenerated:{webpack:()=>[83913]},ssr:!1});var $=()=>{let e;let[t,i]=(0,r.useState)(!1),{companyProfileResult:n}=(0,l.v9)(e=>e[c._.REDUX]),{getDataResult:s,employeeServiceDetails:m}=(0,l.v9)(e=>e[o._.REDUX]),p=()=>{let e=(s?.dataSource??[]).filter(e=>e?.employeeId===g.ZP.get(d.P.userSerivceDetails)?.id);if(!(0,u.QC)(e))return;let t=F(e,n,g.ZP.get(d.P.userSerivceDetails)?.name??"").replace("</style>",` .container-print {
				font-size: 27px;
				}
			.table-business{
				font-size: 27px;
				}		
			</style>`);(0,u.b5)(t)},x=(0,r.useMemo)(()=>{let e=(s?.dataSource??[]).filter(e=>e?.employeeId===m);return!(0,u.QC)(e)},[m,s]),f=g.ZP.get(d.P.userSerivceDetails);return e=(0,a.jsx)(W,{handlePrintTechnician:p,isOpen:t}),(0,a.jsx)(a.Fragment,{children:(0,a.jsx)(A,{title:"Service Details",visibleTitle:!0,subTitle:f?.name??"ALL",RightCompoent:[(0,a.jsx)(h.Z,{className:"button-tab",variant:"outlined",sx:{width:"max-content !important",...x&&{background:"#E6F1FB !important",color:"#A1C9EF !important"}},onClick:p,text:"PRINT TECHNICIAN"})],children:e})})}}},function(e){e.O(0,[7847,6388,1357,9664,4446,2507,9774,2888,179],function(){return e(e.s=45370)}),_N_E=e.O()}]);