"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[944],{80944:function(e,a,s){s.r(a);var t=s(85893),n=s(61599),c=s(67294),r=s(89250),i=s(25932),o=s(8188),f=s(1218),g=s(74064),h=s(14237),l=s(93346),u=s(58656);s(90475);var y=s(41248),m=s(53289),d=s(2017),D=s(94230),w=s(89352),p=s(83075),v=s(16533),x=s(39878),P=s(82265);let S=n.Z.div`
	max-width: 100%;
	width: 100%;
	margin: 0 auto;
	// justify-content: center;
	align-items: stretch;
	display: flex;
	// flex-direction: column;
	height: 100vh;
`;a.default=({children:e})=>{let a=(0,y.I0)(),{connection:s}=(0,i.s)(),{companyProfileResult:n,countRerender:Z}=(0,y.v9)(e=>e[o._.REDUX]),{refreshData:j}=(0,w.C)(),{refreshData:k}=(0,p.H)(),{refreshData:E}=(0,m.g)(),{refreshData:I}=(0,x.C)(),{syncData:R}=(0,D.m)(),{refreshData:C}=(0,d.c)(),{syncData:_}=(0,v.o)(),b={voidReasons:async()=>{u.ZP.setStorage("voidReasons",[]),await I()},categories:async()=>{u.ZP.setStorage("categories",[]),await E()},departments:async()=>{u.ZP.setStorage("departments",[]),await C()},discounts:async()=>{u.ZP.setStorage("discounts",[]),await R()},employees:async()=>{a(g.kD.setSynchronizing(!0)),await j(),a(g.kD.setSynchronizing(!1))},menuItems:async()=>{u.ZP.setStorage("menuItems",[]),await k()},taxes:async()=>{await _()}};return(0,c.useEffect)(()=>{if(s){let e=async(e,a)=>{if(console.log("\uD83D\uDE80 ~ handleReceiveMessage ~ merchantId, message:",e,a),"all"===e&&b[a](),e===n?.merchantId){let e;try{e=JSON.parse(a)}catch(s){e=a}b[a]&&b[a](),"object"==typeof e&&b[e?.message]&&b[e?.message](e)}};return s.on("ReceiveMessage",e),()=>{s.off("ReceiveMessage",e)}}},[s,n]),(0,c.useEffect)(()=>{(0,l.K0)(n)||a(f.VI.getCompanyProfileAsync())},[n]),(0,t.jsxs)(S,{children:[(0,t.jsx)(h.ZP,{}),(0,t.jsx)(P.ZP,{}),e,(0,t.jsx)(r.j3,{})]})}}}]);