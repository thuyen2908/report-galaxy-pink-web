"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[2157],{2157:function(e,t,i){i.r(t);var s=i(85893),n=i(61599);i(67294);var a=i(89250),c=i(14237),h=i(82265);let l=n.Z.div`
	max-width: 100%;
	width: 100%;
	margin: 0 auto;
	// justify-content: center;
	align-items: stretch;
	display: flex;
	// flex-direction: column;
	height: 100vh;
`;t.default=({children:e})=>(0,s.jsxs)(l,{children:[(0,s.jsx)(c.ZP,{}),(0,s.jsx)(h.ZP,{}),e,(0,s.jsx)(a.j3,{})]})}}]);