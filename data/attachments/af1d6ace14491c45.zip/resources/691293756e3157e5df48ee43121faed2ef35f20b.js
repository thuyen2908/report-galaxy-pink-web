(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[2197],{20394:function(n,e,t){(window.__NEXT_P=window.__NEXT_P||[]).push(["/404",function(){return t(98733)}])},98733:function(n,e,t){"use strict";t.r(e);var r=t(85893);t(67294);var o=t(61599),i=t(41664),a=t.n(i),c=t(70405),u=t(51015),d=t(96788),h=t(1830);let s=(0,o.Z)(u.Z)(h.ZP),l=o.Z.div`
	padding: ${n=>n.theme.spacing(6)};
	text-align: center;
	background: transparent;
	display: flex;
	flex-direction: column;
	align-items: center;
	justify-content: center;
	height: 100%;
	padding-bottom: ${n=>n.theme.spacing(5)};
	${n=>n.theme.breakpoints.up("md")} {
		padding: ${n=>n.theme.spacing(10)};
	}
`;function g(){return(0,r.jsxs)(l,{children:[(0,r.jsx)(c.ql,{title:"404 Error"}),(0,r.jsx)(d.Z,{component:"h1",variant:"h1",align:"center",gutterBottom:!0,children:"404"}),(0,r.jsx)(d.Z,{component:"h2",variant:"h5",align:"center",gutterBottom:!0,children:"Page not found."}),(0,r.jsx)(d.Z,{component:"h2",variant:"body1",align:"center",gutterBottom:!0,children:"The page you are looking for might have been removed."}),(0,r.jsx)(s,{component:a(),href:"/",variant:"contained",color:"secondary",mt:2,children:"Return to website"})]})}g.getLayout=function(n){return(0,r.jsx)(r.Fragment,{children:n})},e.default=g}},function(n){n.O(0,[5063,9774,2888,179],function(){return n(n.s=20394)}),_N_E=n.O()}]);