(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[6687],{45370:function(e,t,a){(window.__NEXT_P=window.__NEXT_P||[]).push(["/management/service-details",function(){return a(9450)}])},63661:function(e,t,a){"use strict";var i=a(85893);a(67294);var r=a(88196),l=a(52857),s=a(40110),n=a(93454),d=a(61193),c=a.n(d),o=a(93346),g=a(36039),u=a(38444),h=a(70152),m=a(53865);function p(e){return(0,i.jsx)(c(),{handle:"#draggable-dialog-title",cancel:'[class*="MuiDialogContent-root"]',children:(0,i.jsx)(n.Z,{...e})})}t.Z=({className:e="",isOpen:t,title:a="",children:n,maxWidth:d="1000px",minHeight:c="200px",maxHeight:x="400px",minWidth:b,onClose:f,loading:v,iconActive:y,isActive:E,overflow:S,sx:k={},iconClose:j=!0})=>(0,i.jsxs)(r.Z,{open:t,onClose:f,sx:{"& .MuiDialog-container":{"& > .MuiPaper-root":{width:"100%",maxWidth:d,height:"auto",minHeight:c,maxHeight:x,minWidth:b,overflow:S,backgroundColor:"unset"}},...k},PaperComponent:p,"aria-labelledby":"draggable-dialog-title",className:e,children:[!(0,o.Ew)(a)&&(0,i.jsxs)(i.Fragment,{children:[v&&(0,i.jsx)(h.Z,{loading:v}),(0,i.jsxs)(m.rz,{children:[y&&(0,i.jsx)(g.Z,{color:E?"success":"error",sx:{width:"25  px",height:"25px"}}),a]}),j&&(0,i.jsx)(l.Z,{"aria-label":"close",title:"Close",onClick:f,sx:{position:"absolute",right:8,top:8},children:(0,i.jsx)(u.Z,{color:"white"})})]}),(0,i.jsx)(s.Z,{children:n})]})},20142:function(e,t,a){"use strict";var i=a(85893),r=a(32726),l=a(63792),s=a(93346);a(67294);var n=a(27684);let d=[{display:"flex",alignItem:"center",field:"avatar",headerName:"",minWidth:80,groupable:!1,aggregable:!1,sortable:!1,width:80,valueGetter:(e,t)=>`${t?.nickName}`,renderCell:e=>{let{firstName:t,lastName:a,backColor:i,foreColor:r,avatar:l}=e.row;return(0,s.Ew)(l)?(0,s.gk)(t,a,i,r):(0,s.Ik)(l)}},{field:"nickName",headerName:"Name",minWidth:115,width:115,flex:1}];t.Z=({onSelect:e})=>{let{technicians:t}=(0,l.Z)();return(0,i.jsx)(i.Fragment,{children:(0,i.jsx)(r.Z,{gridProps:{...n.tyM},columns:d,countRow:!1,dataRow:t,onRowClick:e})})}},9450:function(e,t,a){"use strict";a.r(t),a.d(t,{default:function(){return $}});var i=a(85893),r=a(67294),l=a(41248),s=a(5152),n=a.n(s),d=a(90475),c=a(8188),o=a(28886),g=a(93346),u=a(58656),h=a(27603),m=a(4762),p=a(70405),x=a(58531),b=a(68573),f=a(27684),v=a(18704),y=a(32726),E=a(22507),S=({data:e,allTechnician:t=!1,handleOnRowClick:a})=>{let{loading:r}=(0,l.v9)(e=>e[o._.REDUX]),{loading:s}=(0,l.v9)(e=>e[v._.REDUX]),{companyProfileResult:n}=(0,l.v9)(e=>e[c._.REDUX]),d=[{field:"nickName",headerName:"Technician",minWidth:120,groupable:!1,aggregable:!1,hideable:!0},{field:"ticketNumber",headerName:"Ticket#",minWidth:80,groupable:!1,aggregable:!1},{field:"itemName",headerName:"Service",minWidth:300,flex:1,groupable:!1,aggregable:!1,valueFormatter:(e,t)=>`${t.menuItemType===f.UIn.ServicePackageItem||t.menuItemType===f.UIn.PrePaidPackageItem?"==":""}${e??""}`},{field:"qty",headerName:"Qty",width:70,groupable:!1,type:f.ga8.Number},{field:"originalPrice",headerName:"Price",minWidth:100,width:120,align:"right",groupable:!1,type:f.ga8.Number,headerAlign:"right",valueFormatter:e=>(0,g.xG)(e)},{field:"nonCashTip",headerName:"NC Tips",minWidth:100,groupable:!1,type:f.ga8.Number,align:"right",headerAlign:"right",valueFormatter:e=>(0,g.xG)(e)},{field:"originalDiscount",headerName:"Discount Total",minWidth:160,align:"right",groupable:!1,type:f.ga8.Number,headerAlign:"right",valueFormatter:e=>(0,g.xG)(e)},{field:"serviceChargeTotal",headerName:"Item Supply Fee",minWidth:180,groupable:!1,type:f.ga8.Number,align:"right",headerAlign:"right",valueFormatter:e=>(0,g.xG)(e)},{field:"supplyCharge",headerName:"Ticket Supply Fee",minWidth:180,groupable:!1,type:f.ga8.Number,align:"right",headerAlign:"right",valueFormatter:e=>(0,g.xG)(e)}];return(0,i.jsx)(y.Z,{fullHeight:!0,columns:d,gridProps:{...f.tyM,disableAggregation:!1,initialState:{aggregation:{model:{serviceChargeTotal:"sum",qty:"sum",originalPrice:"sum",nonCashTip:"sum",originalDiscount:"sum",supplyCharge:"sum"}}}},customFilter:t?null:[(0,i.jsx)(E.Z,{type:"horizontal",firstDayOfWeek:n?.weekStartsOn},"date-range")],dataRow:e??[],loading:r||s,onRowClick:a})},k=a(60762),j=({id:e})=>{let{dataBillServiceDetails:t}=(0,l.v9)(e=>e[v._.REDUX]),{companyProfileResult:a}=(0,l.v9)(e=>e[c._.REDUX]),[s,n]=(0,r.useState)("");return(0,r.useEffect)(()=>{if((0,g.K0)(t)){if(!(0,g.K0)(t?.dataSource)){n("");return}let e=u.ZP.get(d.P.QrCode),i=t?.dataSource;(0,g.Ew)(a?.receiptMessage?.qrCodeCustomerReceipt)||(i=t?.dataSource?.replace("</body>",`<div class='qr'>
						<img src=${e} />
						</div></div></body>`)),n(i)}},[a?.receiptMessage?.qrCodeCustomerReceipt,t]),(0,i.jsx)(r.Fragment,{children:(0,i.jsx)(k.Z,{className:"render-bill",dangerouslySetInnerHTML:{__html:(0,g.K0)(t)?s:""}})})},P=a(9677),w=a(71820),I=a(68780),D=a(20142),T=a(69364),C=a(79010),N=a(85017),_=a(91309),Z=a(30381),R=a.n(Z);let W=(0,m.Z)({VIEW_ALL_SERVICE_DETAILS:(0,i.jsx)(T.Fo,{children:(0,i.jsx)(()=>{let e=(0,l.I0)(),t=(0,r.useRef)(""),{getDataResult:a}=(0,l.v9)(e=>e[o._.REDUX]),{companyProfileResult:s}=(0,l.v9)(e=>e[c._.REDUX]),{value:n}=(0,T.zT)(),[h,m]=(0,r.useState)([]),[v,y]=(0,r.useState)(null),[k,N]=(0,r.useState)([]);return(0,r.useEffect)(()=>{let t={dateStart:n?.[0].format(C.qx),dateEnd:n?.[1].format(C.qx)};e(P.f.getPaidServicesByDateRangeAsync(t))},[n]),(0,r.useEffect)(()=>{if((0,g.K0)(a)&&a.result){m(a.dataSource);let e=a.dataSource;(0,g.K0)(v)&&(e=e.filter(e=>e.employeeId===v?.id)),N(e)}},[a]),(0,r.useEffect)(()=>()=>{e(P.f.clearDataEmployeeTicket()),(0,g.FC)(f.uH8.VIEW_ALL_SERVICE_DETAILS),u.ZP.remove(d.P.userSerivceDetails),e(w.Xz.clearDataEmployeeTicket())},[]),(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(p.ql,{title:"Service Details"}),(0,i.jsxs)(b.ZP,{container:!0,height:"100%",flexWrap:"nowrap",children:[(0,i.jsx)(b.ZP,{item:!0,xs:2,lg:2,height:"100%",position:"relative",children:(0,i.jsxs)(I.Wc,{heightclassic:"278px",heightlinear:"155px",sx:{display:"flex",flexDirection:"column",gap:2},children:[(0,i.jsx)(E.Z,{firstDayOfWeek:s?.weekStartsOn}),(0,i.jsx)(D.Z,{onSelect:a=>{let i=a.row,r=h?.filter(e=>e.employeeId===i?.id);y(i),N(r),e(P.f.changeEmployeeServiceDetails(i.id)),t.current="",u.ZP.set(d.P.userSerivceDetails,{id:i?.id??"",name:i?.nickName??""}),e(w.Xz.clearBillCloseTicket("dataBillServiceDetails"))}})]})}),(0,i.jsx)(b.ZP,{pl:2,item:!0,xs:7.5,lg:7.5,children:(0,i.jsx)(I.Wc,{heightlinear:"155px",children:(0,i.jsx)(x.x4,{children:(0,i.jsx)(S,{data:k,allTechnician:!0,handleOnRowClick:a=>{if(t.current!==a?.id){t.current=a?.id??"";let i={ticketId:a?.row.ticketId??"",updatedAt:a?.row?.updatedAt??null,customerId:a?.row?.customerId??""};e(w.Xz.renderBillCloseTicket({keyData:"dataBillServiceDetails",data:i}))}}})})})}),(0,i.jsx)(b.ZP,{pl:2,item:!0,xs:2.5,lg:2.5,children:(0,i.jsx)(I.Wc,{children:(0,i.jsx)(x.x4,{backgroundTab:!1,isScroll:!0,sx:{overflow:"hidden auto","&::-webkit-scrollbar":{display:"none"}},children:(0,i.jsx)(j,{id:t.current})})})})]})]})},{})}),VIEW_ONLY_SERVICE_DETAILS:(0,i.jsx)(T.Fo,{children:(0,i.jsx)(({isOpen:e,handlePrintTechnician:t})=>{let a=(0,r.useRef)(""),s=(0,l.I0)(),{value:n}=(0,T.zT)(),{getDataResult:c}=(0,l.v9)(e=>e[o._.REDUX]),h=u.ZP.get(d.P.userSerivceDetails),[m,f]=(0,r.useState)([]);return(0,r.useEffect)(()=>{a.current=""},[m]),(0,r.useEffect)(()=>{let e={employeeId:h?.id??"",dateStart:n?.[0].format(C.qx),dateEnd:n?.[1].format(C.qx)};s(P.f.getPaidServiceAsync(e))},[n]),(0,r.useEffect)(()=>{(0,g.K0)(c)&&c.result&&f(c.dataSource)},[c]),(0,r.useEffect)(()=>()=>{(0,g.FC)(N.uH.VIEW_ONLY_SERVICE_DETAILS),s(P.f.clearDataEmployeeTicket()),u.ZP.remove(d.P.userSerivceDetails),s(w.Xz.clearDataEmployeeTicket())},[]),(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(p.ql,{title:"Service Details"}),(0,i.jsxs)(b.ZP,{container:!0,height:"100%",flexWrap:"nowrap",children:[(0,i.jsx)(b.ZP,{item:!0,xs:9.5,lg:9.5,children:(0,i.jsx)(I.Wc,{heightclassic:"192px",heightlinear:"155px",children:(0,i.jsx)(x.x4,{children:(0,i.jsx)(S,{data:m,allTechnician:!1,handleOnRowClick:e=>{if(a.current!==e?.id){a.current=e?.id??"";let t={ticketId:e?.row.ticketId??"",updatedAt:e?.row?.updatedAt??null,customerId:e?.row?.customerId??""};s(w.Xz.renderBillCloseTicket({keyData:"dataBillServiceDetails",data:t}))}}})})})}),(0,i.jsx)(b.ZP,{pl:2,item:!0,xs:2.5,lg:2.5,children:(0,i.jsx)(I.Wc,{children:(0,i.jsx)(x.x4,{isScroll:!0,sx:{overflow:"hidden auto","&::-webkit-scrollbar":{display:"none"}},children:(0,i.jsx)(j,{id:a.current})})})})]})]})},{})}),checkRole:!0}),A=(e,t,a)=>{let i="",r=0,l=0,s=0;return(e||[]).forEach((e,t,a)=>{l+=e.nonCashTip,s+=e.originalPrice,r+=e.qty,i+=`<tr class="${0===t?"bold-start":t===a.length-1?"bold-end":""}">
			<td class="name">${e.menuItemType===f.UIn.ServicePackageItem||e.menuItemType===f.UIn.PrePaidPackageItem?"==":""}${e.itemName}</td>
			<td class="right-align right-qty">${e.qty}</td>
			<td class="right-align">${(0,g.xG)(e.nonCashTip)}</td>
			<td class="right-align">${(0,g.xG)(e.originalPrice)}</td>
		</tr>`}),`<html>
					<style>
						 .class-address {
							text-align: center;
							margin-top: 0px;
							margin-bottom: 0px;
							line-height: 1.2;
						}

						.table-business {
							width: 100%;
							border-collapse: collapse;
							table-layout: fixed; 
						}

						.dashed-service {
							border-top: 1px dashed black;
							border-bottom: 1px dashed black;
							margin: 10px 0;
						}

						.name {
							text-align: left;
							width: 40%;
						}

						.right-align {
							text-align: right;
							vertical-align: top;
							width: 25%; 
						}

						.center-align {
							text-align: center;
						}

						.border-top {
							border-top: 1px dashed black;
						}

						.border-end {
							border-top: 2px dashed black;
							padding-top: 5px;
						}

						.bold-end>td {
							padding-bottom: 5px
						}

						.bold-first>td {
							padding-bottom: 8px
						}

						.bold-start>td {
							padding-top: 8px
						}

						.container-print {
							font-size: 20px;
							font-family: Verdana;
						}

						.container-print {
							font-size: 25px;
						}

						.table-business {
							font-size: 25px;
						}
						.right-qty{
							width:10%
						}
					</style>
					<body>
						<div class='container-print'>
						<p class='class-address'>${t?.businessName??""}</p>
						<p class='class-address'>${t?.address?.address??""}<br>${t?.address?.city}, ${t?.address?.state} ${t?.address?.zip}<br>${(0,_.un)(t?.phone??"")}</p>
						<table class="table-business">
							<tr>
								<td class="name">Business Date</td>
								<td class="right-align" colspan="3">${R()(new Date).format(C.GG)}</td>
							</tr>
							<tr>
								<td class="name">Technician Name</td>
								<td class="right-align" colspan="3">${a}</td>
							</tr>
						</table>
						<table class="table-business">
							<tr class="bold-first">
								<td class="name">Service/Prod</td>
								<td class="right-align right-qty">Qty</td>
								<td class="right-align">Tip</td>
								<td class="right-align">Total</td>
							</tr>
							<tr class="border-end">

							</tr>
							${i}
							<tr class="border-end">
							</tr>
							<tr class="bold-start">
								<td class="name">TOTAL</td>
								<td class="right-align right-qty">${r}</td>
								<td class="right-align">${(0,g.xG)(l)}</td>
								<td class="right-align">${(0,g.xG)(s)}</td>
							</tr>
						</table>
						</div>
					</body>
				</html>`},F=n()(()=>Promise.all([a.e(4380),a.e(4644),a.e(5869),a.e(2857),a.e(3487),a.e(4022),a.e(6266),a.e(1290),a.e(4726),a.e(5063),a.e(8189),a.e(7497),a.e(6107),a.e(6966),a.e(6748),a.e(525),a.e(9481),a.e(629),a.e(8836),a.e(4254)]).then(a.bind(a,46056)),{loadableGenerated:{webpack:()=>[46056]},ssr:!1});var $=()=>{let e;let[t,a]=(0,r.useState)(!1),{companyProfileResult:s}=(0,l.v9)(e=>e[c._.REDUX]),{getDataResult:n,employeeServiceDetails:m}=(0,l.v9)(e=>e[o._.REDUX]),p=()=>{let e=(n?.dataSource??[]).filter(e=>e?.employeeId===u.ZP.get(d.P.userSerivceDetails)?.id);if(!(0,g.QC)(e))return;let t=A(e,s,u.ZP.get(d.P.userSerivceDetails)?.name??"").replace("</style>",` .container-print {
				font-size: 27px;
				}
			.table-business{
				font-size: 27px;
				}		
			</style>`);(0,g.b5)(t)},x=(0,r.useMemo)(()=>{let e=(n?.dataSource??[]).filter(e=>e?.employeeId===m);return!(0,g.QC)(e)},[m,n]),b=u.ZP.get(d.P.userSerivceDetails);return e=(0,i.jsx)(W,{handlePrintTechnician:p,isOpen:t}),(0,i.jsx)(i.Fragment,{children:(0,i.jsx)(F,{title:"Service Details",visibleTitle:!0,subTitle:b?.name??"ALL",RightCompoent:[(0,i.jsx)(h.Z,{className:"button-tab",variant:"outlined",sx:{width:"max-content !important",...x&&{background:"#E6F1FB !important",color:"#A1C9EF !important"}},onClick:p,text:"PRINT TECHNICIAN"})],children:e})})}}},function(e){e.O(0,[7847,6388,2188,4321,4446,4007,9774,2888,179],function(){return e(e.s=45370)}),_N_E=e.O()}]);